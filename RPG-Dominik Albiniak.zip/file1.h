class SPECIAL {
    int strenght;
    int perception;
    int endurance;
    int charisma;
    int intelligence;
    int agility;
    int luck;

    int hp;
    int mp;
public:
    SPECIAL () {
        strenght = 0;
        perception = 0;
        endurance = 0;
        charisma = 0;
        intelligence = 0;
        agility = 0;
        luck = 0;
        hp = 0;
        mp = 0;
    }
    SPECIAL (int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        strenght = a;
        perception = b;
        endurance = c;
        charisma = d;
        intelligence = e;
        agility = f;
        luck = g;
        hp = h;
        mp = i;
    }
    void set_stre(int s) {
        strenght = s;
    }
    void set_pre(int p) {
        perception = p;
    }
    void set_end(int e) {
        endurance = e;
    }
    void set_char(int c) {
        charisma = c;
    }
    void set_int (int i) {
        intelligence = i;
    }
    void set_agi(int a) {
        agility = a;
    }
    void set_luck(int l) {
        luck = l;
    }
    void set_hp(int h) {
        hp = h;
    }
    void set_mp(int m) {
        mp = m;
    }
    int ret_stre() {
        return strenght;
    }
    int ret_per() {
        return perception;
    }
    int ret_end() {
        return endurance;
    }
    int ret_char() {
        return charisma;
    }
    int ret_int() {
        return intelligence;
    }
    int ret_agi() {
        return agility;
    }
    int ret_luck() {
        return luck;
    }
    int ret_hp() {
        return hp;
    }
    int ret_mp() {
        return mp;
    }
};


