#include "file1.h"
class human {
    int level;
    public:
    human (int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        level = 0;
        SPECIAL p(5, 5, 5, 5, 5, 5, 5, 100, 10);
    }
    void levelUpp() {
        level++;
    }
};
class elf {
    int level;
    public:
    elf (int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        level = 0;
        SPECIAL p(2, 8, 6, 4, 7, 6, 4, 90, 15);
    }
};
class dwarf {
    int level;
    public:
    dwarf (int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        level = 0;
        SPECIAL p(10, 4, 5, 3, 3, 3, 5, 130, 5);
    }
};
class darkElf {
    int level;
    public:
    darkElf (int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        level = 0;
        SPECIAL p(4, 6, 6, 2, 7, 7, 7, 95, 12);
    }
};
class fairy {
    int level;
    public:
    fairy (int a, int b, int c, int d, int e, int f, int g, int h, int i) {
        level = 0;
        SPECIAL p(1, 3, 3, 5, 10, 6, 8, 70, 30);
    }
};
class goblin {
    public:
    SPECIAL* p;
    goblin() {
        p = new SPECIAL(4, 4, 4, 0, 0, 2, 1, 60, 15);
    }
};
class snake {
    public:
    SPECIAL* p;
    snake() {
        p = new SPECIAL(6, 3, 3, 3, 3, 3, 3, 30, 0);
    }
};
class skeleton {
    public:
    SPECIAL* p;
    skeleton() {
        p = new SPECIAL(5, 2, 2, 1, 5, 1, 1, 40, 10);
    }
};
class ol {
    public:
    SPECIAL* p;
    ol() {
        p = new SPECIAL(11, 1, 2, 1, 1, 1, 1, 120, 0);
    }
};
class knight {
    public:
    SPECIAL* p;
    knight () {
        p = new SPECIAL(7, 2, 2, 2, 2, 2, 2, 90, 0);
    }
};
class knightBoss {
    public:
    SPECIAL* p;
    knightBoss() {
        p = new SPECIAL(10, 3, 3, 3, 3, 3, 3, 100, 5);
    }
};

