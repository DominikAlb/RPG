//Dominik Albiniak
#include "file2.h"
#include <string>
#include "weapons.h"
class map {
    int x;
    int y;
    bool areYouWasHere;
    public:
    map () {
        x = 0;
        y = 0;
        areYouWasHere = false;
    }
    map(int x, int y) {
        this -> x = x;
        this -> y = y;
        areYouWasHere = false;
    }
    map(int x, int y, bool argument) {
        this -> x = x;
        this -> y = y;
        areYouWasHere = argument;
    }
    int ret_x() {
        return x;
    }
    int ret_y() {
        return y;
    }
    void set_x(int set) {
        x = set;
    }
    void set_y(int set) {
        y = set;
    }
    bool ret_bool() {
        return areYouWasHere;
    }
};
int SimAttack (SPECIAL *npc) {
    return npc->ret_stre() + int(0.5 * npc->ret_agi());
}
int MagAttack (SPECIAL *npc) {
    int n = npc->ret_mp();
    n = n - 2;
    npc->set_mp(n);
    return npc->ret_int() + int(0.2 * npc->ret_mp());
}
int NonSimAttack (Weapons *wep, SPECIAL *npc) {
    int n = npc->ret_mp();
    npc->set_mp(n - wep->mp());
    return int(wep->dam() + 1.5 * wep->fire() + 0.5 * wep->ice() + 0.75 * wep->poison() + 1.25 * wep->shock());
}
int choice(SPECIAL *npc, int choice, Weapons* wep) {
    int damage = 0;
    if (choice == 1) {
        damage = SimAttack(npc);
    } else if (choice == 2) {
        if (npc->ret_int() > 9) {
            int n;
            printf("\n1:fireball\n2:schock\n3:blizzard\n4:poison\n5:help\n");
            scanf("%i", &n);
            if (n == 1) {
                damage = 10;
                int m = npc->ret_mp();
                if (m - 5 >= 0) npc->set_mp(m - 5); else damage = MagAttack(npc);
            } else if (n == 2) {
                damage = 15;
                int m = npc->ret_mp();
                if (m - 7 >= 0) npc->set_mp(m - 7); else damage = MagAttack(npc);
            } else if (n == 3) {
                damage = 5;
                int m = npc->ret_mp();
                if (m - 2 >= 0) npc->set_mp(m - 2); else damage = MagAttack(npc);
            } else if (n == 4) {
                damage = 7;
                int m = npc->ret_mp();
                if (m - 3 >= 0) npc->set_mp(m - 3); else damage = MagAttack(npc);
            } else if (n == 5) {
                printf("\n-HELP-\n1:fireball damage:10\n mp cost:5\n2:schock damage:15\n mp cost:7\n3:blizzard damage:5\nmp cost:2\n4:poison damage:7\nmp cost 3\n");
            }
        } else damage = MagAttack(npc);
    } else if (choice == 3) {
        //printf("Uzyj jednego slowa np: do Small axe napisz Small\n");
        char* take = new char[15];
        show_all();
        scanf("%s", take);
        *wep = pick(take);
        damage = NonSimAttack(wep, npc);
        delete[] take;
    }
    return damage;
}
int fight(SPECIAL* hero, int choicee) {
    Weapons* wep = new Weapons();
    return choice(hero, choicee, wep);
}
void kosciotrup(SPECIAL* hero) {
    skeleton* sna = new skeleton();
    int choicee;
    printf("\nSamouczek\n1:\tZwykly atak\n2:\tAtak magia\n3:\tPodnies bron i nia zaatakuj\n");
    while (sna->p->ret_hp() > 0 && hero->ret_hp() > 0) {
        printf("\ntwoje zycie: %i twoja mana: %i \t zycie przeciwnika: %i \n", hero->ret_hp(),hero->ret_mp(), sna->p->ret_hp());
        printf("\nTwoj wybor: ");
        scanf("%i", &choicee);
        int health = sna->p->ret_hp();
        sna->p->set_hp(health - fight(hero, choicee));
        printf("ruch przeciwnika:\n");
        health = hero->ret_hp();
        hero->set_hp(health - MagAttack(sna->p));
    }
    delete sna;
}
void waz (SPECIAL* hero) {
    snake* sna = new snake();
    int choicee;
    printf("\nSamouczek\n1:\tZwykly atak\n2:\tAtak magia\n3:\tPodnies bron i nia zaatakuj\n");
    while (sna->p->ret_hp() > 0 && hero->ret_hp() > 0) {
        printf("\ntwoje zycie: %i twoja mana: %i \t zycie przeciwnika: %i \n", hero->ret_hp(),hero->ret_mp(), sna->p->ret_hp());
        printf("\nTwoj wybor: ");
        scanf("%i", &choicee);
        int health = sna->p->ret_hp();
        sna->p->set_hp(health - fight(hero, choicee));
        printf("ruch przeciwnika:\n");
        health = hero->ret_hp();
        hero->set_hp(health - SimAttack(sna->p));
    }
    delete sna;
}
void goblins (SPECIAL* hero) {
    goblin* sna = new goblin();
    int choicee;
    int i = 1;
    printf("\nSamouczek\n1:\tZwykly atak\n2:\tAtak magia\n3:\tPodnies bron i nia zaatakuj\n");
    while (sna->p->ret_hp() > 0 && hero->ret_hp() > 0) {
        printf("\ntwoje zycie: %i twoja mana: %i \t zycie przeciwnika: %i \n", hero->ret_hp(),hero->ret_mp(), sna->p->ret_hp());
        printf("\nTwoj wybor: ");
        scanf("%i", &choicee);
        int health = sna->p->ret_hp();
        sna->p->set_hp(health - fight(hero, choicee));
        printf("ruch przeciwnika:\n");
        health = hero->ret_hp();
        if (i%4 != 0) hero->set_hp(health - SimAttack(sna->p));
        else hero->set_hp(health - MagAttack(sna->p));
        i++;
    }
    delete sna;
}
void knights(SPECIAL* hero) {
    knight* sna = new knight();
    int choicee;
    printf("\nSamouczek\n1:\tZwykly atak\n2:\tAtak magia\n3:\tPodnies bron i nia zaatakuj\n");
    while (sna->p->ret_hp() > 0 && hero->ret_hp() > 0) {
        printf("\ntwoje zycie: %i twoja mana: %i \t zycie przeciwnika: %i \n", hero->ret_hp(),hero->ret_mp(), sna->p->ret_hp());
        printf("\nTwoj wybor: ");
        scanf("%i", &choicee);
        int health = sna->p->ret_hp();
        sna->p->set_hp(health - fight(hero, choicee));
        printf("ruch przeciwnika:\n");
        health = hero->ret_hp();
        hero->set_hp(health - SimAttack(sna->p));
    }
    delete sna;
}
void knightsB(SPECIAL* hero) {
    knightBoss* sna = new knightBoss();
    int choicee;
    int i = 1;
    printf("\nSamouczek\n1:\tZwykly atak\n2:\tAtak magia\n3:\tPodnies bron i nia zaatakuj\n");
    while (sna->p->ret_hp() > 0 && hero->ret_hp() > 0) {
        printf("\ntwoje zycie: %i twoja mana: %i \t zycie przeciwnika: %i \n", hero->ret_hp(),hero->ret_mp(), sna->p->ret_hp());
        printf("\nTwoj wybor: ");
        scanf("%i", &choicee);
        int health = sna->p->ret_hp();
        sna->p->set_hp(health - fight(hero, choicee));
        printf("ruch przeciwnika:\n");
        health = hero->ret_hp();
        if (i%4 != 0) hero->set_hp(health - SimAttack(sna->p));
        else hero->set_hp(health - MagAttack(sna->p));
        i++;
    }
    delete sna;
}
void olb(SPECIAL* hero) {
    ol* sna = new ol();
    int choicee;
    printf("\nSamouczek\n1:\tZwykly atak\n2:\tAtak magia\n3:\tPodnies bron i nia zaatakuj\n");
    while (sna->p->ret_hp() > 0 && hero->ret_hp() > 0) {
        printf("\ntwoje zycie: %i twoja mana: %i \t zycie przeciwnika: %i \n", hero->ret_hp(),hero->ret_mp(), sna->p->ret_hp());
        printf("\nTwoj wybor: ");
        scanf("%i", &choicee);
        int health = sna->p->ret_hp();
        sna->p->set_hp(health - fight(hero, choicee));
        printf("ruch przeciwnika:\n");
        health = hero->ret_hp();
        hero->set_hp(health - SimAttack(sna->p));
    }
    delete sna;
}
bool Gollum () {
    printf("Teraz musisz wygrac z Gollumem. Aby przejsc dalej musisz odpowiedziec na trzy pytania...\n");
    bool tak = true;
    char* odp = new char[15];
    printf("\n\t\t\t---odpowiedz malymi literami bez polskich znakow---\n");

        printf("Korzeni nie widzialo niczyje oko, a przeciez to cos siega bardzo wysoko,\n od drzew wybujalo wspanialej, chociaz nie rosnie wcale.\n");
        scanf("%s", odp);
        char tru1[] = "gora";
        if (*odp != *tru1) {
            tak = false;
            printf("Gollum cie dobija\n");
            return tak;
        }
        printf("Nie ma skrzydel, a trzepocze, nie ma ust, a mamrocze,\n nie ma nog, a plasa, nie ma zebow, a kasa.\n");
        scanf("%s", odp);
        char tru2[] = "wiatr";
        if (*odp != *tru2) {
            tak = false;
            printf("Gollum cie dobija\n");
            return tak;
        }
        printf("Cos, przed czym w swiecie nic nie uciecze, co gnie zelazo,\n przegryza miecze, pozera ptaki, zwierzeta, ziele, najtwardszy kamien na make miele,\n krolow nie szczedzi, rozwala mury, poniza nawet najwyzsze gory.\n");
        scanf("%s", odp);
        char tru3[] = "czas";
        if (*odp != *tru3) {
            tak = false;
            printf("Gollum cie dobija\n");
            return tak;
        }
        return tak;
        delete[] odp;

}
bool found(int x, int y, map* Map) {
    for(int i = 0; i < 19; i++) {
        if (x == Map[i].ret_x() && y == Map[i].ret_y())
            return Map[i].ret_bool();
    }
    return false;
}
bool interaction (int x, int y, SPECIAL* hero, map* Maps) {
    int full_hp = hero->ret_hp();
    int full_mp = hero->ret_mp();
    bool areYouWas = found(x, y, Maps);
    if (x == 2 && y == 0) {
        printf("Walka z wezem!\n");
        if (!areYouWas) {
            waz(hero);
            areYouWas = true;
        } else { //weze x2
            waz(hero);
            if (hero->ret_hp() <= 0)
                return false;
            waz(hero);
        }
    } else if (x == 4 && y == 3) {
        printf("Walka z kosciotrupem!\n");
        if (!areYouWas) {
            kosciotrup(hero);
            areYouWas = true;
        } else { //weze x2
            kosciotrup(hero);
            if (hero->ret_hp() <= 0)
                return false;
            kosciotrup(hero);
        }
    } else if (x == 3 && y == 4) {
        printf("Pulapka!\n-10HP + 4str\n");
        int h = hero->ret_hp();
        hero->set_hp(h - 10);
        full_hp = h - 10;
        int s = hero->ret_stre();
        hero->set_stre(s + 4);
    } else if (x == 5 && y == 5) {
        printf("Walka z goblinami!\n");
        if (!areYouWas) {
            goblins(hero);
            areYouWas = true;
        } else { //weze x2
            goblins(hero);
            if (hero->ret_hp() <= 0)
                return false;
            goblins(hero);
        }
    } else if (x == 3 && y == 5) {
        printf("Walka z rycerzami!\n");
        if (!areYouWas) {
            knights(hero);
            areYouWas = true;
        } else { //weze x2
            knights(hero);
            if (hero->ret_hp() <= 0)
                return false;
            knights(hero);
        }
    } else if (x == 3 && y == 6) {
        printf("Walka z bossem rycerzy!\n");
        if (!areYouWas) {
            knightsB(hero);
            areYouWas = true;
        }
    } else if (x == 5 && y == 6) {
        printf("Walka z olbrzymem!\n");
        if (!areYouWas) {
            olb(hero);
            areYouWas = true;
        }
    } else if (x == 4 && y == 7) {
        return Gollum();
    } else if (x == 4 && y == 8) {
        return false;
    }
    if (hero->ret_hp() > 0) {//usun to
        hero->set_hp(full_hp);
        hero->set_mp(full_mp);
    }   else return false;
    return true;
}
void showLoc (int x, int y) {
    FILE* loc;
    loc = fopen("location.txt", "r");
    if (loc == NULL) {
        printf("Error 404\n"); return void();
    }
    int x1, y1;
    fscanf(loc, "%i", &x1);
    fscanf(loc, "%i", &y1);
    char s = ' ';
    while ( x1 != x || y1 != y ) {
        while(s != '\n') {
            fscanf(loc, "%c", &s);
        }
        fscanf(loc, "%i", &x1);
        fscanf(loc, "%i", &y1);
        fscanf(loc, "%c", &s);
    }
    while(s != '\n' && s != EOF) {
            fscanf(loc, "%c", &s);
            printf("%c", s);
    }
    fclose(loc);
}
void locate (class map* Map, class map* player) {
    //printf("%i", Map[5].ret_x());
            printf("you can go:\n");

    for (int i = 0; i < 19; i++)
            if (Map[i].ret_x() == player->ret_x() + 1 && Map[i].ret_y() == player->ret_y())
                printf("East\n");
    for (int i = 0; i < 19; i++)
            if (Map[i].ret_x() == player->ret_x() - 1 && Map[i].ret_y() == player->ret_y())
                printf("West\n");
    for (int i = 0; i < 19; i++)
            if (Map[i].ret_x() == player->ret_x() && Map[i].ret_y() == player->ret_y() + 1)
                printf("North\n");
    for (int i = 0; i < 19; i++)
            if (Map[i].ret_x() == player->ret_x() && Map[i].ret_y() == player->ret_y() - 1)
                printf("South\n");
}
bool canGo (class map* Map, class map* player) {
    //printf("%i", Map[5].ret_x());
            printf("you can go:\n");

    for (int i = 0; i < 19; i++)
        if (Map[i].ret_x() == player->ret_x() && Map[i].ret_y() == player->ret_y())
            return true;
    return false;
}
bool jest (int x, int y, map* Map) {
    for (int i = 0; i < 19; i++) {
        if (x == Map[i].ret_x() && y == Map[i].ret_y())
            return true;
    }
    return false;
}
void show_map(map* Map, map* player) {
    for(int i = 0; i < 10; i++) {
        for (int j = 0; j < 7; j++) {
            if (player->ret_x() == j && player->ret_y() == i) {
                printf("x ");
            } else if (jest(j, i, Map)) {
                printf("* ");
            } else printf("  ");
        }
        printf("\n");
    }
}
int main () {
    //create map
    map* Map = new map[19];
    Map[0].set_x(0); Map[0].set_y(0);
    Map[1].set_x(1); Map[1].set_y(0);
    Map[2].set_x(2); Map[2].set_y(0);
    Map[3].set_x(3); Map[3].set_y(0);
    Map[4].set_x(3); Map[4].set_y(1);
    Map[5].set_x(4); Map[5].set_y(1);
    Map[6].set_x(4); Map[6].set_y(2);
    Map[7].set_x(4); Map[7].set_y(3);
    Map[8].set_x(3); Map[8].set_y(3);
    Map[9].set_x(3); Map[9].set_y(4);
    Map[10].set_x(4); Map[10].set_y(4);
    Map[11].set_x(4); Map[11].set_y(5);
    Map[12].set_x(5); Map[12].set_y(5);
    Map[13].set_x(3); Map[13].set_y(5);
    Map[14].set_x(3); Map[14].set_y(6);
    Map[15].set_x(4); Map[15].set_y(6);
    Map[16].set_x(5); Map[16].set_y(6);
    Map[17].set_x(4); Map[17].set_y(7);//show_all
    Map[18].set_x(4); Map[18].set_y(8);

    map* player = new map();
    player->set_x(0);
    player->set_y(0);
    //map created - player no name - created direction 0 0
    int get;
    printf("Kim grasz?\n");
    printf("1 - human\n2 - elf\n3 - dwarf\n4 - dark elf\n5 - fairy\n");
    printf("SPECIAL - strenght, perception, endurance, charisma, intelligence, agillity, luck, hp, mp\nhuman - 5, 5, 5, 5, 5, 5, 5, 100, 10\nelf - 2, 8, 6, 4, 7, 6, 4, 90, 15\ndwarf - 10, 4, 5, 3, 3, 3, 5, 130, 5\n");
    printf("darkelf - 4, 6, 6, 2, 7, 7, 7, 95, 12\nfairy - 1, 3, 3, 5, 10, 6, 8, 70, 30\n");
    scanf("%i", &get);
    SPECIAL *p;
    if(get == 1) {
        p = new SPECIAL(5, 5, 5, 5, 5, 5, 5, 100, 10);
    } else if (get == 2) {
        p = new SPECIAL(2, 8, 6, 4, 7, 6, 4, 90, 15);
    } else if (get == 3) {
        p = new SPECIAL(10, 4, 5, 3, 3, 3, 5, 130, 5);
    } else if (get == 4) {
        p = new SPECIAL(4, 6, 6, 2, 7, 7, 7, 95, 12);
    } else if (get == 5) {
        p = new SPECIAL(1, 3, 3, 5, 10, 6, 8, 70, 30);
    }
    char s;
    scanf("%c", &s);
    printf("KIERUNKI N S E W\n");
    int x = player->ret_x();
    int y = player->ret_y();
    showLoc(x, y);
    while (p->ret_hp() > 0) {
        x = player->ret_x();
        y = player->ret_y();
        //printf("%i %i", x, y);
        //printf("%i", p->ret_hp());
        locate(Map, player);
        printf("And you go? : ");
        scanf("%c", &s);
        //printf("%s", &s);
        if (s == 'W') {
            int x = player->ret_x() - 1;
            player->set_x(x);
            if (!canGo(Map, player))
                player->set_x(++x);
        } else if (s == 'E') {
            int x = player->ret_x() + 1;
            player->set_x(x);
            if (!canGo(Map, player))
                player->set_x(--x);
        } else if (s == 'N') {
            int y = player->ret_y() + 1;
            player->set_y(y);
            if (!canGo(Map, player))
                player->set_y(--y);
        } else if (s == 'S') {
            int y = player->ret_y() - 1;
            player->set_y(y);
            if (!canGo(Map, player))
                player->set_y(++y);
        }
        x = player->ret_x();
        y = player->ret_y();
        show_map(Map, player);
        showLoc(x, y);
        if (!interaction(player->ret_x(), player->ret_y(), p, Map))
            p->set_hp(0);
        scanf("%c", &s);
    }

    return 0;
}
