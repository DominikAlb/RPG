#include <string>
#include <stdio.h>
class Weapons {
    int damage;
    int fire_damage;
    int poison_damage;
    int ice_damage;
    int shock_damage;
    int range;
    int mp_cost;
    std::string name;
    public:
    Weapons () {
        damage = 0;
        fire_damage = 0;
        poison_damage = 0;
        ice_damage = 0;
        shock_damage = 0;
        range = 0;
        mp_cost = 0;
        name = "";
    }
    Weapons (int a, int b, int c, int d, int e, int f, int g, std::string z) {
        damage = a;
        fire_damage = b;
        poison_damage = c;
        ice_damage = d;
        shock_damage = e;
        range = f;
        mp_cost = g;
        name = z;
    }
    int dam () {
        return damage;
    }
    int fire() {
        return fire_damage;
    }
    int poison () {
        return poison_damage;
    }
    int ice() {
        return ice_damage;
    }
    int shock() {
        return shock_damage;
    }
    int rang () {
        return range;
    }
    int mp () {
        return mp_cost;
    }
    std::string nm () {
        return name;
    }
    void dam (int d) {
        damage = d;
    }
    void fire(int f) {
        fire_damage = f;
    }
    void poison (int p) {
        poison_damage = p;
    }
    void ice(int i) {
        ice_damage = i;
    }
    void shock(int s) {
        shock_damage = s;
    }
    void rang (int r) {
        range = r;
    }
    void mp (int m) {
        mp_cost = m;
    }
    void nm (std::string n) {
        name = n;
    }
};

void show_all () {
    printf("\nWszystkie bronie\n");
    FILE* loc;
    loc = fopen("weapon.txt", "r");
    if (loc == NULL) {
        printf("Error 400\n"); return void();
    }
    int stats[7];
    char s;
    while ( !feof(loc) && s != EOF ) {
        fscanf(loc, "%i", &stats[0]);
        fscanf(loc, "%i", &stats[1]);
        fscanf(loc, "%i", &stats[2]);
        fscanf(loc, "%i", &stats[3]);
        fscanf(loc, "%i", &stats[4]);
        fscanf(loc, "%i", &stats[5]);
        fscanf(loc, "%i", &stats[6]);
        while(s != '\n' && !feof(loc)) {
            fscanf(loc, "%c", &s);
            printf("%c", s);
            //printf("G");
        }
        //printf("\n %i %i %i %i %i %i %i \n", stats[0], stats[1], stats[2], stats[3], stats[4], stats[5], stats[6]);
        int all = stats[0] + stats[1] + stats[2] + stats[3] + stats[4] + stats[5];
        printf("all damage: %i mp cost: %i \n", all, stats[6]);
        fscanf(loc, "%c", &s);
        //printf("G");
    }
    fclose(loc);
}
Weapons pick (char* choice) {
    FILE* loc;
    //printf("%s \n", choice);
    loc = fopen("weapon.txt", "r");
    if (loc == NULL) {
        class Weapons* s = new Weapons();
        printf("Error 400\n"); return *s;
    }
    int stats[7];
    char s[20];
    char c;
    int i = 0;
    while ( !feof(loc) || s != choice ) {
        //s = "";
        bool tak = true;
        for (int j = 0; j < 20; j++) s[20] = '\0';
        i = 0;
        fscanf(loc, "%i", &stats[0]);
        fscanf(loc, "%i", &stats[1]);
        fscanf(loc, "%i", &stats[2]);
        fscanf(loc, "%i", &stats[3]);
        fscanf(loc, "%i", &stats[4]);
        fscanf(loc, "%i", &stats[5]);
        fscanf(loc, "%i", &stats[6]);
        fscanf(loc, "%c", &c);
        for (int j = 0; j < 4; j++) {
            fscanf(loc, "%c", &c);
            //printf("%c %c\n", c, choice[j]);
            if (c != choice[j])
                tak = false;
        }
        if (tak)
            break;
        while (c != '\n') {
            fscanf(loc, "%c", &c);
            s[i++] = c;
            //printf("%c", c);
        }
        fscanf(loc, "%c", &c);
        //printf("%s %s \n",s, choice);
        //fscanf(loc, "%c", &c);

    }
    //printf("%s", s);
    class Weapons* p = new Weapons(stats[0], stats[1], stats[2], stats[3], stats[4], stats[5], stats[6], s);
    fclose(loc);
    return *p;
}
void drop (class Weapons* wep) {
    delete wep;
    class Weapons* w = new Weapons();
    wep = w;
}
